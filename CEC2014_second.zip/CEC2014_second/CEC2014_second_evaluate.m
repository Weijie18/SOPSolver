function f = CEC2014_second_evaluate(x, func_num)
% Interface to the alternate CEC2014 dispatcher supplied for crash cases.
if ~(isscalar(func_num) && isnumeric(func_num) && isfinite(func_num) && func_num == floor(func_num) && func_num >= 1 && func_num <= 30)
    error('CEC2014_second_evaluate:InvalidFunction', 'CEC2014 function number must be an integer from 1 to 30.');
end
root_dir = fileparts(mfilename('fullpath'));
mex_file = fullfile(root_dir, ['cec14_func.' mexext]);
if ~exist(mex_file, 'file')
    error('CEC2014_second_evaluate:MissingMex', 'Missing alternate CEC2014 MEX file: %s.', mex_file);
end
x = normalize_input(x);
old_dir = pwd;
cleanup_obj = onCleanup(@() cd(old_dir));
cd(root_dir);
f = cec14_func(x, func_num);
end

function x = normalize_input(x)
valid_dims = [2 10 20 30 50 100];
if ~isnumeric(x) || isempty(x)
    error('CEC2014_second_evaluate:InvalidInput', 'x must be a non-empty numeric vector or matrix.');
end
if isvector(x)
    x = x(:);
    return;
end
[r, c] = size(x);
if any(r == valid_dims)
    return;
elseif any(c == valid_dims)
    x = x';
else
    error('CEC2014_second_evaluate:InvalidDimension', 'CEC2014 input dimension must be one of 2, 10, 20, 30, 50, or 100.');
end
end
